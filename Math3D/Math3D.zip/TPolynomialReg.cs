﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Math3D
{
    public class TPolynomialReg
    {
        public double[] Xs = { }, Ys = { }, Ycs;

        public readonly int Rank, W;

        public int Pos { get; private set; } = 0;
        public TPolynomialReg(int rank, int w)
        {
            Rank = rank;
            W = w;
        }

        public void AddValues(double x, double y)
        {
            Array.Resize(ref Xs, Pos + 1);
            Array.Resize(ref Ys, Pos + 1);
            Xs[Pos] = x; Ys[Pos] = y;
            Pos++;
        }

        public void Compute()
        {
            Ycs = new double[Pos];
            double[,] xs, xsr;
            double[] ys, ysr;
            double x, y, dx, dy;
            int current = 0, i;
            xs = new double[Rank + 1, Rank + 1];
            ys = new double[Rank + 1];
            //
            for (i = 0; i < (int)(Math.Min(Pos - 1, current + W)); i++)
            {
                x = Xs[i];
                y = Ys[i];
                //  wtr.WriteLine(x.ToString() + ';' + y.ToString());
                for (int j = 0; j <= Rank; j++)
                {
                    for (int k = 0; k <= Rank; k++)
                        xs[j, k] += Math.Pow(x, j + k);
                    ys[j] += y * Math.Pow(x, j);
                }
            }
            //

            for (current = 0; current < Pos; current++)
            {
                xsr = new double[Rank + 1, Rank + 1];
                ysr = new double[Rank + 1];

                if (current + W < Pos)
                {
                    i = current + W;
                    x = Xs[i];
                    y = Ys[i];
                    //  wtr.WriteLine(x.ToString() + ';' + y.ToString());
                    for (int j = 0; j <= Rank; j++)
                    {
                        for (int k = 0; k <= Rank; k++)
                            xs[j, k] += Math.Pow(x, j + k);
                        ys[j] += y * Math.Pow(x, j);
                    }
                }
                if (current - W >-1)
                {
                    i = current - W;
                    x = Xs[i];
                    y = Ys[i];
                    //  wtr.WriteLine(x.ToString() + ';' + y.ToString());
                    for (int j = 0; j <= Rank; j++)
                    {
                        for (int k = 0; k <= Rank; k++)
                            xs[j, k] -= Math.Pow(x, j + k);
                        ys[j] -= y * Math.Pow(x, j);
                    }
                }


                //  wtr.Close();
                // TFunctions.BuildReversedMatrix(xs, ref xsr);
                TFunctions.BuildVariablesVector((double[,])xs.Clone(), ys, ref ysr);

                x = Xs[current];
                for (int j = 0; j <= Rank; j++)
                    Ycs[current] += ysr[j] * Math.Pow(x, j);
                if (Math.Abs(Ycs[current]) > 500)
                {
                }
            }
        }
        public void ComputeOld()
        {
            Ycs = new double[Pos];
            double[,] xs, xsr;
            double[] ys, ysr;
            double x, y, dx, dy;
            int current = 0;
            for (current = 0; current < Pos; current++)
            {
                xs = new double[Rank + 1, Rank + 1];
                xsr = new double[Rank + 1, Rank + 1];
                ys = new double[Rank + 1];
                ysr = new double[Rank + 1];

                // StreamWriter wtr = new StreamWriter(@"C:\Users\to101757\Documents\csv.csv");
                for (int i = (int)(Math.Max(0, current - W)); i <= (int)(Math.Min(Pos - 1, current + W)); i++)
                {
                    x = Xs[i];
                    y = Ys[i];
                    //  wtr.WriteLine(x.ToString() + ';' + y.ToString());
                    for (int j = 0; j <= Rank; j++)
                    {
                        for (int k = 0; k <= Rank; k++)
                            xs[j, k] += Math.Pow(x, j + k);
                        ys[j] += y * Math.Pow(x, j);
                    }
                }
                //  wtr.Close();
                // TFunctions.BuildReversedMatrix(xs, ref xsr);
                TFunctions.BuildVariablesVector(xs, ys, ref ysr);

                x = Xs[current];
                for (int j = 0; j <= Rank; j++)
                    Ycs[current] += ysr[j] * Math.Pow(x, j);
                if (Math.Abs(Ycs[current]) > 500)
                {
                }
            }
        }
    }
}
